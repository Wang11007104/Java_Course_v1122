   //Name______________________________ Date_____________
   import java.util.Scanner
    public class Driver02
   {
      public static final int NUMITEMS = 15;
       public static void main(String[] args)
      {
      
         //enter your code here
      }
   }