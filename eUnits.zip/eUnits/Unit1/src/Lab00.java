import edu.fcps.karel2.Display;
import edu.fcps.karel2.Robot;


public class Lab00 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Display.openWorld("maps/first.map");
		Robot karel = new Robot();
	}

}
